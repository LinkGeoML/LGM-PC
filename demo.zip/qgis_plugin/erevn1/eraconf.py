class eraconfig:

	#poi_fpath = '/media/disk/LGM-Classification-mybranch/data/marousi_pois.csv'
	#poi_fpath = 'C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\data\\pois_data.csv'
	#experiments_path = '/media/disk/LGM-Classification-mybranch/experiments'
	#experiments_path = 'C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\experiments'
	#experiments_path = 'C:/Users/geft/Downloads/LGM-PC-master/LGM-PC-master/LGM-Classification/experiments'

	pythonexepath="C:\\Program Files\\QGIS 3.6\\apps\\Python37\\python.exe" 

	uiformfilepath="C://Users//geft//AppData//Roaming//QGIS//QGIS3//profiles//default//python//plugins//erevn1//pois_data.ui"
	uiformcodepath="C://Users//geft//AppData//Roaming//QGIS//QGIS3//profiles//default//python//plugins//erevn1//pois_data.py"

	#spythonclassifyalgfile
	pythonmodeldeployment="C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\model_deployment.py"
	pythonpoifilepath2deploy="C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\data\\" 
	pythonexppath2deploy="C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\exp_22-07-2019_12-55-51\\"
	exppath="C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\exp_22-07-2019_12-55-51\\model_deployment_resultsgrg1\\"



	pythonpoifile4trainpath="C:\\Users\\geft\\Downloads\\LGM-Classification-master1"
	#pythonfinetunefile="C:\\Users\\geft\\Downloads\LGM-Classification-master1\\finetune_best_clf.py"
	#pythonexportbestmodelfile="C:\\Users\\geft\\Downloads\LGM-Classification-master1\\export_best_model.py"	
	#pythonsimpleclassificationfile="C:\\Users\\geft\\Downloads\LGM-Classification-master1\\simple_classification.py"
	pythonfeaturesextraction="C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\features_extraction.py"
	pythonalgorithmselection="C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\algorithm_selection.py"
	pythonmodelselection="C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\model_selection.py"
	pythonmodeltraining="C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\model_training.py"


