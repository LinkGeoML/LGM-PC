import os
import sys
import datetime
import csv
from PyQt5 import uic
from PyQt5 import QtCore, QtWidgets,uic
from PyQt5.QtWidgets import QMainWindow, QLabel, QGridLayout, QWidget, QMenu,QAction
from PyQt5.QtWidgets import QPushButton,QFileDialog
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import QSize
from PyQt5.QtGui import *  
from PyQt5.QtCore import *  
from PyQt5.QtSql import QSqlQueryModel,QSqlDatabase,QSqlQuery,QSqlTableModel
from qgis.core import *
from qgis.gui import *
from PyQt5.QtWidgets import QTableWidget,QTableWidgetItem
from qgis.PyQt.QtWidgets import QWidget,QTableView,QLineEdit,QMessageBox
from PyQt5.QtSql import QSqlQueryModel,QSqlDatabase,QSqlQuery,QSqlTableModel
import psycopg2
import re
import  time,subprocess,datetime  


#FORM_CLASS, _ = uic.loadUiType(os.path.join(
#		os.path.dirname(__file__), 'initpois.ui'))

def my_form_open(dialog, layer, feature):
		
		geom = feature.geometry()
		#tableView = dialog.findChild(QTableView, "tableView")
		global tableWidget
		global exppath
		exppath="C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\exp_22-07-2019_12-55-51\\model_deployment_resultsgrg1\\"
		tableWidget = dialog.findChild(QTableWidget, "tableWidget")
		#test = dialog.findChild(QLineEdit, "test")
		#QMessageBox.information(dialog,"Info", str(feature.id()))
		#QMessageBox.information(dialog,"Info", str(feature.attribute("poi_id")))
		#createTable(dialog,tableWidget,feature.attribute("id"),10) 
		#createTable(dialog,tableWidget,feature.id(),10)
		#showcsvdata(dialog,tableWidget,feature.attribute("poi_id"))
		#readandconvertresults(dialog,tableWidget,feature.attribute("poi_id"))
		filltable(dialog,tableWidget,feature.attribute("poi_id"))

def filltable(self,tableWidget,poi_id):
		tableWidget.setRowCount(5)		
		tableWidget.setColumnCount(3)
		tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("POI_id"))
		tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("CATEGORY"))
		tableWidget.setHorizontalHeaderItem(2, QTableWidgetItem("SCORE"))
		#csv_file= open('C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\exp_22-07-2019_12-55-51\\model_deployment_results\\predictions.csv', encoding="utf8")# �� ���� ����������?
		csv_filepath=exppath+"predictionsrplconverted.csv"
		with open(csv_filepath, newline='', encoding='UTF-8') as csv_file:
			csv_data = csv.reader(csv_file, delimiter=',')
			count = 0
			count1 = 0
			for row in csv_data:
			 	#QMessageBox.information( self,"Info", str(row[1]))
				if count < 0:
					#QMessageBox.information( self,"Info", 'str(row[0]')
					count=0
					count1=0
					#QMessageBox.information( self,"Info", str(row[1]).decode('utf-8'))
					continue
				else:
					if len(str(row))>2:					
						#QMessageBox.information(self,"Info",str(len(str(row))))
						if count < 0:
							QMessageBox.information(self,"Info", str(row[0]))
						#cur0.execute ("INSERT INTO tmppoicats(poiid,  cat)  VALUES ("+row[0]+","+row[1]+")")
						#cur0.execute ("INSERT INTO tmppoicats(poiid,  cat)  VALUES ("+row[0]+","+row[2]+")")
						if str(row[0]).replace(",","")==str(poi_id):
							#QMessageBox.information(self,"Info", str(row[1]))
							a=row[0]
							b=row[1]
							c=row[2]

							item11=QTableWidgetItem(str(row[0]))
							item12=QTableWidgetItem(str(row[1]))
							item13=QTableWidgetItem(str(row[2]))


							item11.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item12.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item13.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsEditable)

							tableWidget.setColumnWidth(0, 10);
							tableWidget.setColumnWidth(1, 200);
							tableWidget.setColumnWidth(3, 200);
							tableWidget.setItem(count,0, item11) 
							tableWidget.setItem(count,1, item12) 
							tableWidget.setItem(count,2, item13) 
							count=count+1

def onclick(rindex,cindex):		
			#rindex=tableWidget.selectionModel().currentIndex().row()
			#rindex=tableWidget.currentRow()
			#cindex=tableWidget.currentColumn()
			##tableWidget = dialog.findChild(QTableWidget, "tableWidget")
			
			flags = tableWidget.item(1,4).flags()
			if cindex==4:#flags & QtCore.Qt.ItemIsUserCheckable:
				#QMessageBox.information( self.myiface.mainWindow(),"Info",str(tableWidget.item(0,3).checkState())
				conn_string= "host='localhost' dbname='afanapptry1' user='admin' password='12345'"
				conn = psycopg2.connect(conn_string)
				cur0 = conn.cursor()
				updstr="update tmppoicats set validcat=case when "+str(tableWidget.item(rindex,4).checkState()) +"=2 then 1 else 0 end where poiid=" + tableWidget.item(rindex,0).text() +" and cat="+tableWidget.item(rindex,2).text() 
				#updstr="update tmppoicats set validcat=1 where poiid=" + tableWidget.item(rindex,0).text() +" and cat="+tableWidget.item(rindex,2).text() 
				#QMessageBox.information(None,"Info", updstr)
				cur0.execute(updstr)
				conn.commit()
				cur0.close()
				conn.close()

def readandconvertresults(self,tableWidget,poi_id):
		tableWidget.setRowCount(4)		
		tableWidget.setColumnCount(3)
		tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("POI_id"))
		tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("CATEGORY"))
		tableWidget.setHorizontalHeaderItem(2, QTableWidgetItem("SCORE"))
		#csv_file= open('C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\exp_22-07-2019_12-55-51\\model_deployment_results\\predictions.csv', encoding="utf8")# �� ���� ����������?
		csv_filepath=exppath+"predictionsrpl.csv"
		with open(csv_filepath, newline='', encoding='greek') as csv_file:
			with open(exppath+"predictionsrplconverted.csv", 'a') as myfile:
				csv_data = csv.reader(csv_file, delimiter=',')
				count = 0
				count1 = 0
				for row in csv_data:
				 	#QMessageBox.information( self,"Info", str(row[1]))
					if count < 1:
						#QMessageBox.information( self,"Info", 'str(row[0]')
						count=1
						count1=1
						#QMessageBox.information( self,"Info", str(row[1]).decode('utf-8'))
						continue
					else:
						#QMessageBox.information(self,"Info", "str(a)")
						if count < 0:
							QMessageBox.information(self,"Info", str(row[0]))
						#cur0.execute ("INSERT INTO tmppoicats(poiid,  cat)  VALUES ("+row[0]+","+row[1]+")")
						#cur0.execute ("INSERT INTO tmppoicats(poiid,  cat)  VALUES ("+row[0]+","+row[2]+")")
						if str(row[0]).replace(",","")==str(poi_id):
							a=row[0]

							b=row[1]
							c=eval(b)
							c1=eval(str(c[1]).replace("(","[").replace(")","]"))
							c2=eval(str(c[2]).replace("(","[").replace(")","]"))
							c3=eval(str(c[3]).replace("(","[").replace(")","]"))
							c4=eval(str(c[4]).replace("(","[").replace(")","]"))
							wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
							#mylist=[[row[0],c1[0],c1[1]],[row[0],c2[0],c2[1]]]
							#mylist=[row[0],c1[0],c1[1]]
							wr.writerow([row[0],c1[0],c1[1]])
							wr.writerow([row[0],c2[0],c2[1]])
							wr.writerow([row[0],c3[0],c3[1]])
							wr.writerow([row[0],c4[0],c4[1]])


							item11=QTableWidgetItem(str(row[0]))
							item12=QTableWidgetItem(str(c1[0]))
							item13=QTableWidgetItem(str(c1[1]))
							item21=QTableWidgetItem(str(row[0]))
							item22=QTableWidgetItem(str(c2[0]))
							item23=QTableWidgetItem(str(c2[1]))
							item31=QTableWidgetItem(str(row[0]))
							item32=QTableWidgetItem(str(c3[0]))
							item33=QTableWidgetItem(str(c3[1]))
							item41=QTableWidgetItem(str(row[0]))
							item42=QTableWidgetItem(str(c4[0]))
							item43=QTableWidgetItem(str(c4[1]))

							item11.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item12.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item13.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsEditable)
							item21.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item22.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item23.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item31.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item32.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item33.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							tableWidget.setColumnWidth(0, 10);
							tableWidget.setColumnWidth(1, 200);
							tableWidget.setColumnWidth(3, 200);
							tableWidget.setItem(0,0, item11) 

							tableWidget.setItem(0,1, item12) 
							tableWidget.setItem(0,2, item13) 
							tableWidget.setItem(1,0, item21) 
							tableWidget.setItem(1,1, item22) 
							tableWidget.setItem(1,2, item23) 
							tableWidget.setItem(2,0, item31) 
							tableWidget.setItem(2,1, item32) 
							tableWidget.setItem(2,2, item33) 
							tableWidget.setItem(3,0, item41) 
							tableWidget.setItem(3,1, item42) 
							tableWidget.setItem(3,2, item43) 

							#b=row[1]
							#QMessageBox.information(self,"Info", str(row[1]))
							#QMessageBox.information(self,"Info", mylist[0][1])
							#QMessageBox.information(self,"Info", str(c1[0])+' '+str(c1[1]))
							#QMessageBox.information(self,"Info", str(c[1])+' '+str(c[2])+' '+str(c[3])+' '+str(c[4]))
							#QMessageBox.information(self,"Info", str(b[2]))
				count=count+1



################################################################################################################################################################################################
################################################################################################################################################################################################

def showcsvdata(self,tableWidget,poi_id):
		tableWidget.setRowCount(11)		
		tableWidget.setColumnCount(5)


		rownum=0
		csv_file= open('C:\\Users\\geft\\Downloads\\CodeandDatafortestingotherdatasets\\aaa.csv')
		csv_data = csv.reader(csv_file, delimiter=',')
		count = 0
		count1 = 0
		for row in csv_data:
		 	#QMessageBox.information( self,"Info", str(row[1]))
			if count < 1:
				#QMessageBox.information( self,"Info", 'str(row[0]')
				count=1
				count1=1
				#QMessageBox.information( self,"Info", str(row[1]).decode('utf-8'))
				continue
			else:
				#cur0.execute ("INSERT INTO tmppoicats(poiid,  cat)  VALUES ("+row[0]+","+row[1]+")")
				#cur0.execute ("INSERT INTO tmppoicats(poiid,  cat)  VALUES ("+row[0]+","+row[2]+")")
				if str(row[0])==str(poi_id):
					QMessageBox.information( self,"Info", "---------" + str(row[0])+"-"+ str(row[1])+"-"+ str(row[2]))
					
					print (str(row[1]))
					#QMessageBox.information( self,"Info", str(row[0]))
					chkBoxItem=QTableWidgetItem()
					#chkBoxItem2=QCheckBox()
					chkBoxItem.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled) 
					#{ NoItemFlags, ItemIsSelectable, ItemIsEditable, ItemIsDragEnabled, ..., ItemIsUserTristate }
					#chkBoxItem.setCheckState(QtCore.Qt.Checked)
					#if str(row[4])=="0":			
					#	chkBoxItem.setCheckState(QtCore.Qt.Unchecked)
					#else:			
					#	chkBoxItem.setCheckState(QtCore.Qt.Checked)
				
					item1=QTableWidgetItem(str(row[0]))
					item2=QTableWidgetItem(str(row[1]))
					item3=QTableWidgetItem(str(row[2]))
					item4=QTableWidgetItem(str(row[3]))
					item1.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
					item2.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
					item3.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
					item4.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
					tableWidget.setColumnWidth(0, 10);
					tableWidget.setColumnWidth(1, 200);
					tableWidget.setColumnWidth(2, 0);
					tableWidget.setColumnWidth(3, 200);
					tableWidget.setItem(rownum,0, item1) 
					tableWidget.setItem(rownum,1, item2) 
					tableWidget.setItem(rownum,2, item3) 
					tableWidget.setItem(rownum,3, item4) 

					#tableWidget.setItem(rownum,4,chkBoxItem)
					#tableWidget.setItem(rownum,5,QTableWidgetItem("update"))

					#tableWidget.setItem(rownum,2, QTableWidgetItem(str(row[2]))) 
					#tableWidget.setItem(rownum,3, QTableWidgetItem(str(row[3]))) 
					#tableWidget.setItem(rownum,4, QTableWidgetItem(str(row[4]))) 
					#tableWidget.setItem(rownum,5, QTableWidgetItem(str(row[5]))) 
					#tableWidget.setItem(rownum,6, QTableWidgetItem(str(row[6]))) 
					#tableWidget.setItem(rownum,7, QTableWidgetItem(str(row[7]))) 
					#tableWidget.setItem(rownum,8, QTableWidgetItem(str(row[8]))) 
					QMessageBox.information( self,"Info", "---------" + str(row[0])+"-"+ str(row[1])+"-"+ str(row[2]))
					rownum=rownum+1
					count1=count1+1
			count=count+1
				#cur0.execute(qrystr)
		#self.tableWidget.setRowCount(counter)
		#self.tableWidget.setColumnCount(9)
		tableWidget.setRowCount(count1-1)

		csv_file.close()



		#mexri edo b;azo ta data sto tmppoicats
		#QMessageBox.information( self,"Info", "end")
		#self.createTable(count)
		#QMessageBox.information( self,"Info", "end2")


def onclickold(rindex,cindex):		
			#rindex=tableWidget.selectionModel().currentIndex().row()
			#rindex=tableWidget.currentRow()
			#cindex=tableWidget.currentColumn()
			##tableWidget = dialog.findChild(QTableWidget, "tableWidget")
			
			flags = tableWidget.item(1,4).flags()
			if cindex==4:#flags & QtCore.Qt.ItemIsUserCheckable:
				#QMessageBox.information( self.myiface.mainWindow(),"Info",str(tableWidget.item(0,3).checkState())
				conn_string= "host='localhost' dbname='afanapptry1' user='admin' password='12345'"
				conn = psycopg2.connect(conn_string)
				cur0 = conn.cursor()
				updstr="update tmppoicats set validcat=case when "+str(tableWidget.item(rindex,4).checkState()) +"=2 then 1 else 0 end where poiid=" + tableWidget.item(rindex,0).text() +" and cat="+tableWidget.item(rindex,2).text() 
				#updstr="update tmppoicats set validcat=1 where poiid=" + tableWidget.item(rindex,0).text() +" and cat="+tableWidget.item(rindex,2).text() 
				#QMessageBox.information(None,"Info", updstr)
				cur0.execute(updstr)
				conn.commit()
				cur0.close()
				conn.close()
				
################################################################################################################################################################################################
################################################################################################################################################################################################
		
def createTableold(self,tableWidget,fid,counter):
	   # Create table
			#self.tableWidget = QTableWidget()
 
		conn_string= "host='localhost' dbname='afanapptry1' user='admin' password='12345'"
		conn = psycopg2.connect(conn_string)
		cur0 = conn.cursor()
		qrystr="SELECT poiid, poiname, cat,cat_descr, validcat FROM vtmppoicats  where poiid="+ str(fid)+"   order by poiid,cat"
		cur0.execute(qrystr)
		tableWidget.setRowCount(counter)
		tableWidget.setColumnCount(5)
		rownum=0
		for row in cur0:
			chkBoxItem=QTableWidgetItem()
			#chkBoxItem2=QCheckBox()
			chkBoxItem.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled) 
			#{ NoItemFlags, ItemIsSelectable, ItemIsEditable, ItemIsDragEnabled, ..., ItemIsUserTristate }
			#chkBoxItem.setCheckState(QtCore.Qt.Checked)
			if str(row[4])=="0":			
				chkBoxItem.setCheckState(QtCore.Qt.Unchecked)
			else:			
				chkBoxItem.setCheckState(QtCore.Qt.Checked)

				
			item1=QTableWidgetItem(str(row[0]))
			item2=QTableWidgetItem(str(row[1]))
			item3=QTableWidgetItem(str(row[2]))
			item4=QTableWidgetItem(str(row[3]))
			item1.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
			item2.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
			item3.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
			item4.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
			tableWidget.setColumnWidth(0, 10);
			tableWidget.setColumnWidth(1, 200);
			tableWidget.setColumnWidth(2, 0);
			tableWidget.setColumnWidth(3, 200);
			tableWidget.setItem(rownum,0, item1) 
			tableWidget.setItem(rownum,1, item2) 
			tableWidget.setItem(rownum,2, item3) 
			tableWidget.setItem(rownum,3, item4) 
			tableWidget.setItem(rownum,4,chkBoxItem)
			#tableWidget.setItem(rownum,5,QTableWidgetItem("update"))

			#tableWidget.setItem(rownum,2, QTableWidgetItem(str(row[2]))) 
			#tableWidget.setItem(rownum,3, QTableWidgetItem(str(row[3]))) 
			#tableWidget.setItem(rownum,4, QTableWidgetItem(str(row[4]))) 
			#tableWidget.setItem(rownum,5, QTableWidgetItem(str(row[5]))) 
			#tableWidget.setItem(rownum,6, QTableWidgetItem(str(row[6]))) 
			#tableWidget.setItem(rownum,7, QTableWidgetItem(str(row[7]))) 
			#tableWidget.setItem(rownum,8, QTableWidgetItem(str(row[8]))) 
			rownum=rownum+1

		tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("id"))
		tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("POI"))
		tableWidget.setHorizontalHeaderItem(2, QTableWidgetItem("catid"))
		tableWidget.setHorizontalHeaderItem(3, QTableWidgetItem("���������"))
		tableWidget.setHorizontalHeaderItem(4, QTableWidgetItem(""))
		#tableWidget.setHorizontalHeaderItem(5, QTableWidgetItem(""))
		#tableWidget.setItem(0,0, QTableWidgetItem("TEXT"))
		#tableWidget.setItem(0,1, QTableWidgetItem("Cell (1,2)"))
		#tableWidget.setItem(0,2,chkBoxItem)
			#	  	chkBoxItem=QTableWidgetItem()

			#	  chkBoxItem.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled)
			#	  chkBoxItem.setCheckState(QtCore.Qt.Unchecked)	   
			#	  chkBoxItem2=QTableWidgetItem()
			#	  chkBoxItem2.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled)
			#	  chkBoxItem2.setCheckState(QtCore.Qt.Unchecked)	   
			#tableWidget.setItem(1,0, QTableWidgetItem("Cell (2,1)"))
			#tableWidget.setItem(1,1, QTableWidgetItem("Cell (2,2)"))
			#tableWidget.setItem(1,2,chkBoxItem2)
			#tableWidget.setItem(2,0, QTableWidgetItem("Cell (3,1)"))
			#tableWidget.setItem(2,1, QTableWidgetItem("Cell (3,2)"))
			#tableWidget.setItem(3,0, QTableWidgetItem("Cell (4,1)"))
			#tableWidget.setItem(3,1, QTableWidgetItem("Cell (4,2)"))

			#tableWidget.setItem(2,2,chkBoxItem2)
			#tableWidget.setItem(3,2,chkBoxItem)
			#tableWidget.move(0,0)
		#tableWidget.cellChanged.connect(on_click) # SOS ��� �� �������� �������!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
		tableWidget.cellChanged.connect(onclick)
#def on_click(rindex,cindex):

		
		
def testonlyskonaki(dialog):
		
		db=QSqlDatabase.addDatabase("QPSQL")
		
		if not db:
			QMessageBox.information( dialog,"Info", " ERROR DATABASE" )
		db.setDatabaseName("afanapp")
		db.setUserName("admin")
		db.setPassword("12345")
		db.setHostName("localhost")
		db.setPort(5432);
		try:
			db.open()
		except:
			QMessageBox.information( dialog,"Info", "COULD NOT CONNECT TO DATABASE" )

		#test.setText(qrystr)
		#try:
		if 1==1:

			projectModel = QSqlTableModel(dialog,db)
			#projectModel.setQuery(qrystr,db)
			projectModel.setTable("vtmppoicats")
			projectModel.select()
			#QMessageBox.information( dialog,"Info", str(projectModel.database()) )
			#QMessageBox.information( dialog,"Info", str(projectModel.rowCount()) )

			projectView = tableView
			projectModel.setHeaderData(1, Qt.Horizontal, "poiid")
			projectModel.setHeaderData(2, Qt.Horizontal, "poiname")
			projectModel.setHeaderData(3, Qt.Horizontal, "cat1")
			projectModel.setHeaderData(4, Qt.Horizontal, "subcat1a")
			projectModel.setHeaderData(5, Qt.Horizontal, "subcat1b")
			projectView.setModel(projectModel)
			projectView.show()
		#except:
		#	QMessageBox.information( self,"Info", "COULD NOT RETRIEVE DATA1")

		tableView.setColumnWidth(0,10)
		tableView.setColumnWidth(1,80)
		tableView.setColumnWidth(2,150)

		tableView.setColumnWidth(3,180)
		tableView.setColumnWidth(4,80)
