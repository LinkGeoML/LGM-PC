print("123")
input("Press Enter to continue...")
#subprocess.run(["C:\\Program Files\\QGIS 3.6\\apps\\Python37\\python.exe" ,"C:\\Users\\geft\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\erevn1\\test.py"]) 
#subprocess.run(["C:\\Program Files\\QGIS 3.6\\apps\\Python37\\python.exe" ,"C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\features_extraction.py"])
#"C:\\Program Files\\QGIS 3.6\\apps\\Python37\\python.exe" "C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\features_extraction.py"
#subprocess.run(["C:\\Program Files\\QGIS 3.6\\apps\\Python37\\python.exe" ,"C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\algorithm_selection.py" ,"-experiment_path","C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\exp_22-07-2019_12-55-51\\"])
#"C:\\Program Files\\QGIS 3.6\\apps\\Python37\\python.exe" "C:\\Users\\geft\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\algorithm_selection.py" "-experiment_path" "C:\\Users\\geft\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\exp_22-07-2019_12-55-51\\"