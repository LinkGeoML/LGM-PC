
import os

from PyQt5 import uic
from PyQt5 import QtWidgets

import sys
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QMainWindow, QLabel, QGridLayout, QWidget
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import QSize
from PyQt5.QtGui import *  
from PyQt5.QtCore import *  
from qgis.core import *
from qgis.gui import *




#class EREVN1Dialog(QtWidgets.QDialog, FORM_CLASS):
 
def testsub(a,b):
        return a+b
		

def testsub2(a,b):
        return a*b
