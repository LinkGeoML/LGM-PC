import os
class eraconfig:


	pythonexepath="C:\\Program Files\\QGIS 3.6\\apps\\Python37\\python.exe" 

	#path for create model
	#pythonpoifile4trainpath="C:\\Users\\geft\\Downloads\\LGM-Classification-master1"
	pythonpoifile4trainpath="C:\\Users\\demo\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification"
	#pythonfinetunefile="C:\\Users\\geft\\Downloads\LGM-Classification-master1\\finetune_best_clf.py"
	#pythonexportbestmodelfile="C:\\Users\\geft\\Downloads\LGM-Classification-master1\\export_best_model.py"	
	#pythonsimpleclassificationfile="C:\\Users\\geft\\Downloads\LGM-Classification-master1\\simple_classification.py"
	pythonfeaturesextraction="C:\\Users\\demo\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\features_extraction.py"
	pythonalgorithmselection="C:\\Users\\demo\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\algorithm_selection.py"
	pythonmodelselection="C:\\Users\\demo\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\model_selection.py"
	pythonmodeltraining="C:\\Users\\demo\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\model_training.py"

	
	#path for model deployment
	pythonmodeldeployment="C:\\Users\\demo\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\model_deployment.py" #model
	pythonpoifilepath2deploy="C:\\Users\\demo\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\data\\marousi_pois.csv" #poi file path
	with open('C:/Users/demo/Downloads/LGM-PC-master/LGM-PC-master/LGM-Classification/exp_path.txt', 'r') as file:
		exp_name = file.read().replace('\n', '')
	pythonexppath2deploy=	"C:\\Users\\demo\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\" + exp_name + "\\" #exp path
	exppath=		"C:\\Users\\demo\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\" + exp_name + "\\model_deployment_results\\"
	#exppath the path for era modified files
	
	#path for custom form (POI Layer)
	uiformfilepath="C://Users//demo//AppData//Roaming//QGIS//QGIS3//profiles//default//python//plugins//erevn1//formui//pois_data.ui"
	uiformcodepath="C://Users//demo//AppData//Roaming//QGIS//QGIS3//profiles//default//python//plugins//erevn1//formui//pois_data.py"







