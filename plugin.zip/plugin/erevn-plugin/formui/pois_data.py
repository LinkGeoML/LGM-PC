import os
import sys
import datetime
import csv
from PyQt5 import uic
from PyQt5 import QtCore, QtWidgets,uic
from PyQt5.QtWidgets import QMainWindow, QLabel, QGridLayout, QWidget, QMenu,QAction
from PyQt5.QtWidgets import QPushButton,QFileDialog
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import QSize
from PyQt5.QtGui import *  
from PyQt5.QtCore import *  
#from PyQt5.QtSql import QSqlQueryModel,QSqlDatabase,QSqlQuery,QSqlTableModel
from qgis.core import *
from qgis.gui import *
from PyQt5.QtWidgets import QTableWidget,QTableWidgetItem
from qgis.PyQt.QtWidgets import QWidget,QTableView,QLineEdit,QMessageBox
from PyQt5.QtSql import QSqlQueryModel,QSqlDatabase,QSqlQuery,QSqlTableModel
#import psycopg2
import re
import time,subprocess,datetime  
import shutil
from tempfile import NamedTemporaryFile
#FORM_CLASS, _ = uic.loadUiType(os.path.join(
#		os.path.dirname(__file__), 'initpois.ui'))

#from .eraconf import eraconfig



def my_form_open(dialog, layer, feature):
		global exppath
		with open('C:/Users/demo/Downloads/LGM-PC-master/LGM-PC-master/LGM-Classification/exp_path.txt', 'r') as file:
			exp_name = file.read().replace('\n', '')
		print(exp_name)
		exppath="C:\\Users\\demo\\Downloads\\LGM-PC-master\\LGM-PC-master\\LGM-Classification\\" + exp_name + "\\model_deployment_results\\"
		#USES ONLY THE model_deployment_resultsgrg1\\predictionsrplconverted.csv
		geom = feature.geometry()
		global tableWidget
		global myupdatebtn
		global featureid
		#thepath=os.path.dirname(os.path.abspath(__file__)) #os.path.abspath(os.path.dirname(sys.argv[0])) #os.path.dirname(os.path.abspath(__file__)) #os.getcwd()
		#QMessageBox.information(None,"Info", exppath)
		tableWidget = dialog.findChild(QTableWidget, "tableWidget")
		#print(tableWidget.columnCount(), tableWidget.rowCount())
		myupdatebtn = dialog.findChild(QPushButton, "myupdatebtn")
		#test = dialog.findChild(QLineEdit, "test")
		#QMessageBox.information(dialog,"Info", str(feature.id()))
		#QMessageBox.information(dialog,"Info", str(feature.attribute("poi_id")))
		#createTable(dialog,tableWidget,feature.attribute("id"),10) 
		#createTable(dialog,tableWidget,feature.id(),10)
		#showcsvdata(dialog,tableWidget,feature.attribute("poi_id"))
		#readandconvertresults(dialog,tableWidget,feature.attribute("poi_id"))
		featureid=feature.attribute("poi_id")
		print(featureid)
		#QMessageBox.information(dialog,"Info", str(featureid))
		filltable(dialog,tableWidget,feature.attribute("poi_id"))
		#print(tableWidget.columnCount(), tableWidget.rowCount())
		myupdatebtn.clicked.connect(myupdatebtncliked)#������� ��� ��� ����� �����������

#def myupdatebtncliked2(self):
#		QMessageBox.information(self,"Info", "11111111111111111str(self.tableWidget.rowCount())") 	


def myupdatebtncliked():
		filename = exppath+"predictionsrplconverted.csv"
		newfilename = filename.replace(".csv","_tmp4.csv")
		#tempfile = NamedTemporaryFile(mode='w', delete=False)
		#QMessageBox.information(None,"Info", str(featureid)) 
		#fields = ['ID', 'Name', 'Course', 'Year']

		with open(filename, newline='') as csvfile:
			with open(newfilename, 'w') as tempfile:
				csv_data = csv.reader(csvfile, delimiter=',')
				
				for row in csv_data:
					if len(str(row))>2:
						if str(row[0])==str(featureid):
							for i in range(0,tableWidget.rowCount()):			
								if str(row[2])==tableWidget.item(i,2).text():
									wr = csv.writer(tempfile , quoting=csv.QUOTE_ALL)
									thechecked=0
									#if i<10 :
									if tableWidget.item(i,4).checkState()==2:
										thechecked=1
										#QMessageBox.information(self,"Info", str(self.tableWidget.item(i,3).checkState()))
									wr.writerow([tableWidget.item(i,0).text(),tableWidget.item(i,1).text() ,tableWidget.item(i,2).text()  ,tableWidget.item(i,3).text(),thechecked])

						else:
							wr = csv.writer(tempfile, quoting=csv.QUOTE_ALL)							
							wr.writerow(row)

		shutil.move(tempfile.name, filename)



		



def filltable(self,tableWidget,poi_id):
		tableWidget.setRowCount(5)		
		tableWidget.setColumnCount(5)
		tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("POI_ID"))
		tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("POI_NAME"))
		tableWidget.setHorizontalHeaderItem(2, QTableWidgetItem("CATEGORY"))
		tableWidget.setHorizontalHeaderItem(3, QTableWidgetItem("SCORE"))
		tableWidget.setHorizontalHeaderItem(4, QTableWidgetItem("CHECKBOX"))
		
		csv_filepath=exppath+"predictionsrplconverted.csv"
		with open(csv_filepath, newline='', encoding='UTF-8') as csv_file:
			csv_data = csv.reader(csv_file, delimiter=',')
			count = 0
			count1 = 0
			for row in csv_data:
			 	#QMessageBox.information( self,"Info", str(row[1]))
				if count < 0:
					#QMessageBox.information( self,"Info", 'str(row[0]')
					count=0
					count1=0
					#QMessageBox.information( self,"Info", str(row[1]).decode('utf-8'))
					continue
				else:
					if len(str(row))>2:
						chkBoxItem=QTableWidgetItem()
						#chkBoxItem2=QCheckBox()
						chkBoxItem.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled) 
						#{ NoItemFlags, ItemIsSelectable, ItemIsEditable, ItemIsDragEnabled, ..., ItemIsUserTristate }
						#chkBoxItem.setCheckState(QtCore.Qt.Checked)
						if str(row[4])=="0":			
							chkBoxItem.setCheckState(QtCore.Qt.Unchecked)
						else:			
							chkBoxItem.setCheckState(QtCore.Qt.Checked)					
						#if count < 0:
						#	QMessageBox.information(self,"Info", str(row[0]))
						if str(row[0]).replace(",","")==str(poi_id):
							#QMessageBox.information(self,"Info", str(row[1]))
							a=row[0]
							aname=row[1]
							b=row[2]
							c=row[3]
							item11=QTableWidgetItem(str(row[0]))
							item12=QTableWidgetItem(str(row[1]))
							item13=QTableWidgetItem(str(row[2]))
							item14=QTableWidgetItem(str(row[3]))
							item11.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item12.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
							item13.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled )
							item14.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled )
							tableWidget.setColumnWidth(0, 50);
							tableWidget.setColumnWidth(1, 150);
							tableWidget.setColumnWidth(2, 150);
							tableWidget.setColumnWidth(3, 150);
							tableWidget.setColumnWidth(4, 100);
							tableWidget.setItem(count,0, item11) 
							tableWidget.setItem(count,1, item12) 
							tableWidget.setItem(count,2, item13) 
							tableWidget.setItem(count,3, item14) 
							tableWidget.setItem(count,4,chkBoxItem)
							count=count+1

def onclick(rindex,cindex):		
			#rindex=tableWidget.selectionModel().currentIndex().row()
			#rindex=tableWidget.currentRow()
			#cindex=tableWidget.currentColumn()
			##tableWidget = dialog.findChild(QTableWidget, "tableWidget")
			
			flags = tableWidget.item(1,4).flags()
			#if cindex==4:#flags & QtCore.Qt.ItemIsUserCheckable:
				#QMessageBox.information( self.myiface.mainWindow(),"Info",str(tableWidget.item(0,3).checkState())

